#include<stdio.h>
int main()
{
	int a[20] = {0};
	int *p = a;
	for(int i = 0; i < 2; i++)
	{
		scanf("%d",(p + i));
	}
	printf("%d",p[1]);
	return 0;
}
