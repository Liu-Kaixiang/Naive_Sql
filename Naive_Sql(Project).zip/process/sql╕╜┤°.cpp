#include<stdio.h>
int main()
{
	int a = 0;
	(double)a = (double)(0.1 - 0.05);
	printf("%lf",a);
	return 0;
}
