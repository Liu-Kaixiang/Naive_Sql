#include<stdio.h>
#include<iostream>

using namespace std;
int main()
{
	int a,b;
	scanf("%d",&a);
	cin >> b;
	printf("%d",b);
	cout << a <<endl;
}
